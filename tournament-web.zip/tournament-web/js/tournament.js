// tournament.js - script dasar
console.log('tournament.js loaded');