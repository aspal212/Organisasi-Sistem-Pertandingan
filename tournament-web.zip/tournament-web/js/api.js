// api.js - script dasar
console.log('api.js loaded');