// main.js - script dasar
console.log('main.js loaded');